Title: Scheduling Application

Purpose: Develop a GUI-based scheduling desktop application for a a global consulting organization

Author: Raymond Baartmans (rbaartm@wgu.edu)

IDE: IntelliJ IDEA 2022.2 (Community Edition)

JDK: Amazon Corretto 17.0.3

JavaFX Version: 17.0.1

How to Run: Set the database URL, database user, and password in the enviroment variables of the project run/debug configuration.

Additional Report: I tracked the amount of appointments by location.

MYSQL Connector Version Number: mysql-connector-java-8.0.29.jar

Lambda Expressions: 4, 1 located in Utils (parenthesize), 3 located in the initialize function of AppointmentForm